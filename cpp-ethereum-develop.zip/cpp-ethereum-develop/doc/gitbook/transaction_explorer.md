# Transaction Explorer

Using the transaction pane

The transaction pane enables you to explore transactions receipts, including 

Input parameters
Return parameters
As well as Event logs
To display the transaction explorer, click on the down triangle icon which is on the right of each transaction, this will expand transaction details:

![](mix_bc.png)



Then you can either copy the content of this transaction in the clipboard, Edit the current transaction (you will have to rerun the blockchain then), or debug the transaction.